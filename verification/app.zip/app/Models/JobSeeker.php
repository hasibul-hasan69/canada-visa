<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobSeeker extends Model
{
    public function companyInfo()
    {
        return $this->hasOne('App\Models\Company','id','companyId');
    }
}
